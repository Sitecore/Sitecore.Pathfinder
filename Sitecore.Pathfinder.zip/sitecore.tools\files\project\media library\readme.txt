﻿Drop your media files in this directory.

Supported formats: .jpg, .jpeg, .png, .gif, .pdf, .doc, .docx

This file can safely be removed.