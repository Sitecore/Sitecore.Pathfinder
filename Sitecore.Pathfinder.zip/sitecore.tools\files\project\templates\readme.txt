﻿Place any templates items in this directory.

This file can safely be removed.