﻿Place any system items in this directory.

This file can safely be removed.