﻿Place any rendering files in this directory.

Supported formats: .cshtml, .aspx, .ascx

This file can safely be removed.