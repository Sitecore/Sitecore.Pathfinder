﻿Place any layout files in this directory.

Supported formats: .cshtml, .aspx

This file can safely be removed.